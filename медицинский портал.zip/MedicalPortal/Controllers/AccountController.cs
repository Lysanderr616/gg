using MedicalPortal.Models;
using MedicalPortal.Data;
using MedicalPortal.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortal.Controllers;

public class AccountController(UserManager<Doctor> userManager, SignInManager<Doctor> signInManager, ApplicationDbContext db) : Controller
{
    [HttpGet] public IActionResult Register() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var doctor = new Doctor { UserName = model.Email, Email = model.Email, FullName = model.FullName, Specialization = model.Specialization };
        var result = await userManager.CreateAsync(doctor, model.Password);
        if (result.Succeeded)
        {
            db.DoctorProfiles.Add(new DoctorProfile { FullName = doctor.FullName, Specialization = doctor.Specialization ?? "Общая практика", PublicEmail = doctor.Email, DoctorId = doctor.Id, Bio = "Профиль врача. Дополните информацию о себе.", City = "Астана", ExperienceYears = 0 });
            await db.SaveChangesAsync();
            await signInManager.SignInAsync(doctor, isPersistent: false);
            return RedirectToAction("Index", "Diagnoses");
        }
        foreach (var error in result.Errors) ModelState.AddModelError("", error.Description);
        return View(model);
    }

    [HttpGet] public IActionResult Login(string? returnUrl = null) { ViewBag.ReturnUrl = returnUrl; return View(); }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
    {
        if (!ModelState.IsValid) return View(model);
        var result = await signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, lockoutOnFailure: false);
        if (result.Succeeded) return Url.IsLocalUrl(returnUrl) ? LocalRedirect(returnUrl!) : RedirectToAction("Index", "Diagnoses");
        ModelState.AddModelError("", "Неверный email или пароль");
        return View(model);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await signInManager.SignOutAsync();
        return RedirectToAction("Index", "Home");
    }
}
