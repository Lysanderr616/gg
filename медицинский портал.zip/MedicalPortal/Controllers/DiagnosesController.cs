using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

[Authorize]
public class DiagnosesController(ApplicationDbContext db, UserManager<Doctor> userManager) : Controller
{
    public async Task<IActionResult> Index(string? search, string? category, string? period)
    {
        var doctorId = userManager.GetUserId(User)!;
        var query = db.Diagnoses.AsNoTracking().Where(x => x.DoctorId == doctorId);
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(x => x.PatientName.Contains(search) || x.Title.Contains(search));
        if (!string.IsNullOrWhiteSpace(category) && category != "Все")
            query = query.Where(x => x.Category == category);
        if (period == "week") query = query.Where(x => x.CreatedAt >= DateTime.UtcNow.AddDays(-7));
        if (period == "month") query = query.Where(x => x.CreatedAt >= DateTime.UtcNow.AddDays(-30));
        ViewBag.Search = search; ViewBag.Category = category; ViewBag.Period = period;
        ViewBag.Total = await db.Diagnoses.CountAsync(x => x.DoctorId == doctorId);
        ViewBag.Today = await db.Diagnoses.CountAsync(x => x.DoctorId == doctorId && x.CreatedAt.Date == DateTime.UtcNow.Date);
        return View(await query.OrderByDescending(x => x.CreatedAt).ToListAsync());
    }

    [HttpGet] public IActionResult Create() => View(new Diagnosis());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Diagnosis model)
    {
        ModelState.Remove(nameof(model.DoctorId));
        if (!ModelState.IsValid) return View(model);
        model.DoctorId = userManager.GetUserId(User)!;
        model.CreatedAt = DateTime.UtcNow;
        db.Diagnoses.Add(model); await db.SaveChangesAsync();
        TempData["Message"] = "Диагноз успешно добавлен";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet] public async Task<IActionResult> Edit(int id)
    {
        var item = await Owned(id);
        return item == null ? NotFound() : View(item);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Diagnosis model)
    {
        if (id != model.Id) return BadRequest();
        var item = await Owned(id);
        if (item == null) return NotFound();
        ModelState.Remove(nameof(model.DoctorId));
        if (!ModelState.IsValid) return View(model);
        item.PatientName = model.PatientName; item.Title = model.Title;
        item.Category = model.Category; item.Notes = model.Notes;
        await db.SaveChangesAsync();
        TempData["Message"] = "Изменения сохранены";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await Owned(id);
        if (item == null) return NotFound();
        db.Diagnoses.Remove(item); await db.SaveChangesAsync();
        TempData["Message"] = "Запись удалена";
        return RedirectToAction(nameof(Index));
    }

    private Task<Diagnosis?> Owned(int id) =>
        db.Diagnoses.FirstOrDefaultAsync(x => x.Id == id && x.DoctorId == userManager.GetUserId(User));
}
