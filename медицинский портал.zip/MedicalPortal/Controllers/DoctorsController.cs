using MedicalPortal.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace MedicalPortal.Controllers;
[Authorize]
public class DoctorsController(ApplicationDbContext db) : Controller {
 public async Task<IActionResult> Index(string? search,string? specialty) {
  var q=db.DoctorProfiles.AsNoTracking();
  if(!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.FullName.Contains(search)||(x.Clinic!=null&&x.Clinic.Contains(search)));
  if(!string.IsNullOrWhiteSpace(specialty)&&specialty!="Все специальности") q=q.Where(x=>x.Specialization==specialty);
  ViewBag.Search=search; ViewBag.Specialty=specialty;
  ViewBag.Specialties=await db.DoctorProfiles.AsNoTracking().Select(x=>x.Specialization).Distinct().OrderBy(x=>x).ToListAsync();
  return View(await q.OrderBy(x=>x.Specialization).ThenBy(x=>x.FullName).ToListAsync());
 }
 public async Task<IActionResult> Details(int id) { var item=await db.DoctorProfiles.AsNoTracking().FirstOrDefaultAsync(x=>x.Id==id); return item==null?NotFound():View(item); }
}
