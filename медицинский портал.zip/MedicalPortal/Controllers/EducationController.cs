using MedicalPortal.Models.Education;
using MedicalPortal.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortal.Controllers;

public class EducationController : Controller
{
    public IActionResult Index()
    {
        var doctors = new Doctor[]
        {
            new Neurologist("Иван Петров", 8),
            new Therapist("Елена Смирнова", 10),
            new Cardiologist("Алексей Иванов", 12),
            new Dentist("Мария Ким", 6)
        };

        var patient = new Patient("Алина Соколова", 28, "Плановый осмотр");
        var appointment = new Appointment(patient, doctors[0], new DateTime(2026, 11, 15, 10, 30, 0));

        return View(new EducationPageViewModel
        {
            Doctors = doctors,
            Patient = patient,
            Appointment = appointment
        });
    }
}
