using Microsoft.AspNetCore.Mvc;

namespace MedicalPortal.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => User.Identity?.IsAuthenticated == true
        ? RedirectToAction("Index", "Diagnoses")
        : View();
}
