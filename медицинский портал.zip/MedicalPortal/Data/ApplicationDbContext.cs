using MedicalPortal.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
namespace MedicalPortal.Data;
public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<Doctor>(options) {
 public DbSet<Diagnosis> Diagnoses => Set<Diagnosis>();
 public DbSet<DoctorProfile> DoctorProfiles => Set<DoctorProfile>();
}
