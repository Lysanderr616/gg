using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Diagnosis
{
    public int Id { get; set; }
    [Required, StringLength(120)]
    public string PatientName { get; set; } = "";
    [Required, StringLength(160)]
    public string Title { get; set; } = "";
    [StringLength(30)]
    public string Category { get; set; } = "Общее";
    [StringLength(1000)]
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    [Required]
    public string DoctorId { get; set; } = "";
    public Doctor? Doctor { get; set; }
}
