using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Doctor : IdentityUser
{
    [Required, StringLength(80)]
    public string FullName { get; set; } = "";
    [StringLength(100)]
    public string? Specialization { get; set; }
}
