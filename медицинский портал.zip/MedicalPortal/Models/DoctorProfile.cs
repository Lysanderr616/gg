using System.ComponentModel.DataAnnotations;
namespace MedicalPortal.Models;
public class DoctorProfile {
 public int Id {get;set;}
 [Required,StringLength(100)] public string FullName {get;set;} = "";
 [Required,StringLength(100)] public string Specialization {get;set;} = "";
 [StringLength(120)] public string? Clinic {get;set;}
 [StringLength(120)] public string? City {get;set;}
 [StringLength(40)] public string? Phone {get;set;}
 [EmailAddress,StringLength(120)] public string? PublicEmail {get;set;}
 [StringLength(1000)] public string? Bio {get;set;}
 [StringLength(30)] public string? Office {get;set;}
 [Range(0,70)] public int ExperienceYears {get;set;}
 public string? DoctorId {get;set;}
 [StringLength(500)] public string? PhotoUrl {get;set;}
}
