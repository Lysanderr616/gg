namespace MedicalPortal.Models.Education;

public class Appointment
{
    public Patient Patient { get; set; }
    public Doctor Doctor { get; set; }
    public DateTime AppointmentDate { get; set; }

    public Appointment(Patient patient, Doctor doctor, DateTime appointmentDate)
    {
        Patient = patient;
        Doctor = doctor;
        AppointmentDate = appointmentDate;
    }

    public void ShowAppointment()
    {
        Console.WriteLine("Запись на приём:");
        Patient.ShowPatientInfo();
        Console.WriteLine($"Врач: {Doctor.Name} ({Doctor.Specialization}), стаж: {Doctor.ExperienceYears} лет");
        Console.WriteLine($"Дата приёма: {AppointmentDate:dd.MM.yyyy HH:mm}");
    }
}
