namespace MedicalPortal.Models.Education;

// Вымышленные данные для демонстрации всех четырёх заданий.
public static class AssignmentDemo
{
    public static void Run()
    {
        Doctor[] doctors =
        {
            new Neurologist("Иван Петров", 8),
            new Therapist("Елена Смирнова", 10),
            new Cardiologist("Алексей Иванов", 12),
            new Dentist("Мария Ким", 6)
        };

        foreach (var doctor in doctors)
        {
            Console.WriteLine($"{doctor.Name} — {doctor.Specialization}, стаж: {doctor.ExperienceYears} лет");
            doctor.Reception();
        }

        var patient = new Patient("Алина Соколова", 28, "Плановый осмотр");
        patient.ShowPatientInfo();

        var appointment = new Appointment(patient, doctors[0], new DateTime(2026, 11, 15, 10, 30, 0));
        appointment.ShowAppointment();
    }
}
