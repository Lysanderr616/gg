namespace MedicalPortal.Models.Education;

// Учебная иерархия врачей. Отдельное пространство имён сохраняет
// существующую модель Doctor, используемую ASP.NET Core Identity.
public abstract class Doctor
{
    protected Doctor(string name, int experienceYears)
    {
        Name = name;
        ExperienceYears = experienceYears;
    }

    public string Name { get; }
    public int ExperienceYears { get; }
    public abstract string Specialization { get; }
    public abstract void Reception();
}

public class Therapist(string name, int experienceYears) : Doctor(name, experienceYears)
{
    public override string Specialization => "Терапевт";
    public override void Reception() => Console.WriteLine("Терапевт проводит общий осмотр пациента");
}

public class Cardiologist(string name, int experienceYears) : Doctor(name, experienceYears)
{
    public override string Specialization => "Кардиолог";
    public override void Reception() => Console.WriteLine("Кардиолог проверяет работу сердечно-сосудистой системы");
}

public class Dentist(string name, int experienceYears) : Doctor(name, experienceYears)
{
    public override string Specialization => "Стоматолог";
    public override void Reception() => Console.WriteLine("Стоматолог проводит осмотр полости рта");
}

public class Neurologist(string name, int experienceYears) : Doctor(name, experienceYears)
{
    public override string Specialization => "Невролог";
    public override void Reception() => Console.WriteLine("Невролог проводит проверку нервной системы");
}
