namespace MedicalPortal.Models.Education;

public class Patient
{
    public string Name { get; set; }
    public int Age { get; set; }
    public string Diagnosis { get; set; }

    public Patient(string name, int age, string diagnosis)
    {
        Name = name;
        Age = age;
        Diagnosis = diagnosis;
    }

    public void ShowPatientInfo()
    {
        Console.WriteLine($"Пациент: {Name}; возраст: {Age}; диагноз: {Diagnosis}");
    }
}
