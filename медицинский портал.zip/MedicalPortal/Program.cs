using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddIdentity<Doctor, IdentityRole>(options =>
{
    options.Password.RequiredLength = 6;
    options.Password.RequireDigit = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.User.RequireUniqueEmail = true;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/Login";
    options.Cookie.Name = "MedicalPortal.Auth";
    options.SlidingExpiration = true;
});

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.EnsureCreated();
    db.Database.ExecuteSqlRaw("""
    CREATE TABLE IF NOT EXISTS DoctorProfiles (Id INTEGER NOT NULL CONSTRAINT PK_DoctorProfiles PRIMARY KEY AUTOINCREMENT, FullName TEXT NOT NULL, Specialization TEXT NOT NULL, Clinic TEXT NULL, City TEXT NULL, Phone TEXT NULL, PublicEmail TEXT NULL, Bio TEXT NULL, Office TEXT NULL, ExperienceYears INTEGER NOT NULL, DoctorId TEXT NULL, PhotoUrl TEXT NULL);
    """);
    // Добавляем столбец фотографий и в уже существующую базу данных.
    var profileColumns = db.Database.SqlQueryRaw<string>("SELECT name AS Value FROM pragma_table_info('DoctorProfiles')").ToList();
    if (!profileColumns.Contains("PhotoUrl"))
        db.Database.ExecuteSqlRaw("ALTER TABLE DoctorProfiles ADD COLUMN PhotoUrl TEXT NULL;");
    // Для уже существующих анкет также назначаем демонстрационные портреты.
    db.Database.ExecuteSqlRaw("UPDATE DoctorProfiles SET PhotoUrl = CASE Id WHEN 1 THEN 'https://randomuser.me/api/portraits/women/44.jpg' WHEN 2 THEN 'https://randomuser.me/api/portraits/men/32.jpg' WHEN 3 THEN 'https://randomuser.me/api/portraits/women/68.jpg' WHEN 4 THEN 'https://randomuser.me/api/portraits/men/75.jpg' WHEN 5 THEN 'https://randomuser.me/api/portraits/men/46.jpg' WHEN 6 THEN 'https://randomuser.me/api/portraits/men/52.jpg' WHEN 7 THEN 'https://randomuser.me/api/portraits/women/49.jpg' WHEN 8 THEN 'https://randomuser.me/api/portraits/men/61.jpg' WHEN 9 THEN 'https://randomuser.me/api/portraits/women/33.jpg' WHEN 10 THEN 'https://randomuser.me/api/portraits/women/65.jpg' WHEN 11 THEN 'https://randomuser.me/api/portraits/men/59.jpg' ELSE 'https://ui-avatars.com/api/?name=' || replace(FullName, ' ', '+') END WHERE PhotoUrl IS NULL OR PhotoUrl = '';");
    if (!db.DoctorProfiles.Any()) {
      db.DoctorProfiles.AddRange(new[] {
       new DoctorProfile { FullName="Анна Сергеевна Волкова", Specialization="Стоматолог", Clinic="Dental Studio", City="Астана", Phone="+7 (7172) 55-10-10", PublicEmail="volkova.demo@medicare.local", ExperienceYears=12, Office="Кабинет 204", Bio="Терапевтическая стоматология, профилактика и лечение кариеса.", PhotoUrl="https://randomuser.me/api/portraits/women/44.jpg" },
       new DoctorProfile { FullName="Дмитрий Олегович Соколов", Specialization="Ветеринар", Clinic="ВетКлиника Дружок", City="Астана", Phone="+7 (7172) 55-10-11", PublicEmail="sokolov.demo@medicare.local", ExperienceYears=9, Office="Приёмная 1", Bio="Общая ветеринарная практика и профилактические осмотры животных.", PhotoUrl="https://randomuser.me/api/portraits/men/32.jpg" },
       new DoctorProfile { FullName="Мария Андреевна Ким", Specialization="Педиатр", Clinic="Детская клиника Здоровье", City="Астана", Phone="+7 (7172) 55-10-12", PublicEmail="kim.demo@medicare.local", ExperienceYears=11, Office="Кабинет 12", Bio="Наблюдение детей, профилактические осмотры и консультации родителей.", PhotoUrl="https://randomuser.me/api/portraits/women/68.jpg" },
       new DoctorProfile { FullName="Ерлан Нурланович Ахметов", Specialization="Терапевт", Clinic="Медицинский центр Астана", City="Астана", Phone="+7 (7172) 55-10-13", PublicEmail="akhmetov.demo@medicare.local", ExperienceYears=15, Office="Кабинет 305", Bio="Первичная диагностика, профилактика и сопровождение пациентов.", PhotoUrl="https://randomuser.me/api/portraits/men/75.jpg" },
       new DoctorProfile { FullName="Алексей Викторович Морозов", Specialization="Нейрохирург", Clinic="Клиника нейрохирургии", City="Астана", Phone="+7 (7172) 55-10-14", PublicEmail="morozov.demo@medicare.local", ExperienceYears=18, Office="Блок B, 3 этаж", Bio="Консультации по заболеваниям нервной системы.", PhotoUrl="https://randomuser.me/api/portraits/men/46.jpg" },
       new DoctorProfile { FullName="Руслан Маратович Ибраев", Specialization="Кардиохирург", Clinic="Центр сердечно-сосудистой хирургии", City="Астана", Phone="+7 (7172) 55-10-15", PublicEmail="ibraev.demo@medicare.local", ExperienceYears=20, Office="Кабинет 410", Bio="Консультации по сердечно-сосудистым заболеваниям.", PhotoUrl="https://randomuser.me/api/portraits/men/52.jpg" },
       new DoctorProfile { FullName="Ольга Павловна Белова", Specialization="Нефролог", Clinic="Медицинский центр Астана", City="Астана", Phone="+7 (7172) 55-10-16", PublicEmail="belova.demo@medicare.local", ExperienceYears=13, Office="Кабинет 218", Bio="Консультации по заболеваниям почек.", PhotoUrl="https://randomuser.me/api/portraits/women/49.jpg" },
       new DoctorProfile { FullName="Тимур Арманович Касымов", Specialization="Уролог", Clinic="Клиника семейного здоровья", City="Астана", Phone="+7 (7172) 55-10-17", PublicEmail="kasymov.demo@medicare.local", ExperienceYears=10, Office="Кабинет 117", Bio="Консультативный приём и профилактика урологических заболеваний.", PhotoUrl="https://randomuser.me/api/portraits/men/61.jpg" },
       new DoctorProfile { FullName="Айгуль Бекеновна Садыкова", Specialization="Акушер-гинеколог", Clinic="Центр женского здоровья", City="Астана", Phone="+7 (7172) 55-10-18", PublicEmail="sadykova.demo@medicare.local", ExperienceYears=16, Office="Кабинет 220", Bio="Женское здоровье, профилактические осмотры и сопровождение беременности.", PhotoUrl="https://randomuser.me/api/portraits/women/33.jpg" },
       new DoctorProfile { FullName="Наталья Игоревна Фёдорова", Specialization="Онколог", Clinic="Онкологический консультативный центр", City="Астана", Phone="+7 (7172) 55-10-19", PublicEmail="fedorova.demo@medicare.local", ExperienceYears=17, Office="Кабинет 502", Bio="Консультации и сопровождение пациентов совместно с профильной командой.", PhotoUrl="https://randomuser.me/api/portraits/women/65.jpg" },
       new DoctorProfile { FullName="Сергей Михайлович Орлов", Specialization="Ревматолог", Clinic="Клиника внутренней медицины", City="Астана", Phone="+7 (7172) 55-10-20", PublicEmail="orlov.demo@medicare.local", ExperienceYears=14, Office="Кабинет 306", Bio="Консультации по заболеваниям суставов и системным воспалительным состояниям.", PhotoUrl="https://randomuser.me/api/portraits/men/59.jpg" }
      }); db.SaveChanges();
    }
}
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Home/Error"); app.UseHsts(); }
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.Run();
