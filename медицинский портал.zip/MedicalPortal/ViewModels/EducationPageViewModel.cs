using MedicalPortal.Models.Education;

namespace MedicalPortal.ViewModels;

public class EducationPageViewModel
{
    public required IReadOnlyList<Doctor> Doctors { get; init; }
    public required Patient Patient { get; init; }
    public required Appointment Appointment { get; init; }
}
