using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.ViewModels;

public class RegisterViewModel
{
    [Required, StringLength(80)] public string FullName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, StringLength(100)] public string Specialization { get; set; } = "";
    [Required, DataType(DataType.Password), MinLength(6)] public string Password { get; set; } = "";
    [Required, DataType(DataType.Password), Compare(nameof(Password), ErrorMessage = "Пароли не совпадают")]
    public string ConfirmPassword { get; set; } = "";
}
